// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>
#include <stdexcept>

/**
 * @brief Encrypts or decrypts a string using the provided key.
 * 
 * This function performs a basic XOR encryption/decryption on the input string using the provided key.
 * Each character of the source string is transformed by XORing it with the corresponding character
 * in the key, which wraps around if the key is shorter than the source string.
 * 
 * @param source The input string to be encrypted or decrypted.
 * @param key The key used for the XOR transformation.
 * @return The transformed string after applying the XOR operation.
 */
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    // get lengths now instead of calling the function every time.
    // this would have most likely been inlined by the compiler, but design for performance.
    const auto key_length = key.length();
    const auto source_length = source.length();

    // Assert that our input data is good
    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    // Loop through the source string char by char
    for (size_t i = 0; i < source_length; ++i)
    {
    	// TODO: student needs to change the next line from output[i] = source[i]
        // Transform each character based on XOR of the key modded constrained to key length
        output[i] = static_cast<char>(source[i] ^ key[i % key_length]);
    }

    // Assert that the output length matches the source length
    assert(output.length() == source_length);

    // return the transformed string
    return output;
}

/**
 * @brief Reads the entire contents of a file into a string.
 *
 * This function opens a file with the given filename, reads its contents into a string, and returns
 * the string. If the file cannot be opened, a runtime error is thrown.
 *
 * @param filename The name of the file to read.
 * @return The contents of the file as a string.
 * @throws std::runtime_error If the file cannot be opened.
 */
std::string read_file(const std::string& filename)
{
    std::ifstream file(filename);
    if (!file)
    {
        throw std::runtime_error("Could not open file: " + filename);
    }

    std::stringstream buffer;
    buffer << file.rdbuf();

    return buffer.str();
}

/**
 * @brief Extracts the student's name from a string.
 *
 * This function finds the first newline character in the input string and returns the substring
 * before the newline as the student's name.
 *
 * @param string_data The input string containing the student's name and other data.
 * @return The student's name extracted from the string.
 */
std::string get_student_name(const std::string& string_data)
{
    std::string student_name;

    // Find the first newline character
    size_t pos = string_data.find('\n');
    // did we find a newline
    if (pos != std::string::npos)
    {
    	// Extract the substring up to the newline character
        student_name = string_data.substr(0, pos);
    }
    return student_name;
}

/**
 * @brief Saves data to a file with a specific format.
 *
 * This function opens a file with the given filename and writes the student name, the current
 * timestamp, the key used, and the data to the file. If the file cannot be opened, a runtime
 * error is thrown.
 *
 * @param filename The name of the file to write to.
 * @param student_name The name of the student to be saved in the file.
 * @param key The key used for encryption or decryption to be saved in the file.
 * @param data The data to be saved in the file.
 * @throws std::runtime_error If the file cannot be opened or the timestamp cannot be retrieved.
 */
void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data)
{
    std::ofstream file(filename);

	if (!file)
    {
        throw std::runtime_error("Could not open file: " + filename);
    }

    // Get the current date and time
	time_t time = std::time(nullptr);
    std::tm tm; // structure to break time down into base components.
    if (localtime_s(&tm, &time) != 0) 
    {
        throw std::runtime_error("Failed to get local time.");
    }

    // Formats Date for output stream
    std::ostringstream date;
    date << std::put_time(&tm, "%Y-%m-%d");

    // Write the content to the file
    file << student_name << '\n'
        << date.str() << '\n'
        //<< key << '\n'  // <---Remove to prevent password output to file for better security
        << data << '\n';
}

/**
 * @brief Main function to demonstrate encryption and decryption.
 *
 * This function reads an input file, encrypts the contents using a key, saves the encrypted data
 * to a file, then decrypts the encrypted data and saves the decrypted data to another file.
 *
 * The function handles exceptions thrown during file operations and displays error messages.
 *
 * @return int Returns 0 on success, or 1 if an error occurs.
 */
int main()
{
    std::cout << "Encyption/Decryption Test!" << "\n\n";

    // input file format
    // Line 1: <students name>
    // Line 2: <Lorem Ipsum Generator website used> https://pirateipsum.me/ (could be https://www.lipsum.com/ or one of https://www.shopify.com/partners/blog/79940998-15-funny-lorem-ipsum-generators-to-shake-up-your-design-mockups)
    // Lines 3+: <lorem ipsum generated with 3 paragraphs> 
    //  Fire in the hole bowsprit Jack Tar gally holystone sloop grog heave to grapple Sea Legs. Gally hearties case shot crimp spirits pillage galleon chase guns skysail yo-ho-ho. Jury mast coxswain measured fer yer chains man-of-war Privateer yardarm aft handsomely Jolly Roger mutiny.
    //  Hulk coffer doubloon Shiver me timbers long clothes skysail Nelsons folly reef sails Jack Tar Davy Jones' Locker. Splice the main brace ye fathom me bilge water walk the plank bowsprit gun Blimey wench. Parrel Gold Road clap of thunder Shiver me timbers hempen halter yardarm grapple wench bilged on her anchor American Main.
    //  Brigantine coxswain interloper jolly boat heave down cutlass crow's nest wherry dance the hempen jig spirits. Interloper Sea Legs plunder shrouds knave sloop run a shot across the bow Jack Ketch mutiny barkadeer. Heave to gun matey Arr draft jolly boat marooned Cat o'nine tails topsail Blimey.

    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrytpteddatafile.txt";
    const std::string key = "password123";

    try
    {
        // try to read sourcefile if exists
        const std::string source_string = read_file(file_name);

        // get the student name from the data file
        const std::string student_name = get_student_name(source_string);

        // encrypt sourceString with key
        const std::string encrypted_string = encrypt_decrypt(source_string, key);

        // save encrypted_string to file
        save_data_file(encrypted_file_name, student_name, key, encrypted_string);

        // decrypt encryptedString with key
        const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

        // save decrypted_string to file
        save_data_file(decrypted_file_name, student_name, key, decrypted_string);

        std::cout
    		<< "Read File: "
    		<< file_name
    		<< " - Encrypted To: "
    		<< encrypted_file_name
    		<< " - Decrypted To: "
    		<< decrypted_file_name
    		<< "\n";
    }
    catch (const std::exception& e)
    {
	    std::cerr
    		<< "Error: "
    		<< e.what()
    		<< "\n";
        return 1;
    }
    return 0;
    // students submit input file, encrypted file, decrypted file, source code file, and key used
}
