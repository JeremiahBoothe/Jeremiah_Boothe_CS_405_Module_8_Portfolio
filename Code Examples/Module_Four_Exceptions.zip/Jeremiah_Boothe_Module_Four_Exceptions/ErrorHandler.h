#pragma once
#ifndef ERROR_HANDLER_H
#define ERROR_HANDLER_H

#include <iostream>
#include <functional>
#include <exception>

/**
 * @class ErrorHandler
 * @brief A custom template class for handling exceptions in functions.
 *
 * The ErrorHandler class is a template that takes a function and its arguments,
 * and handles any exceptions that might be thrown during the execution of that function.
 * It catches standard exceptions and unknown exceptions, logging appropriate error messages.
 *
 * @tparam ReturnType The return type of the function to be handled.
 * @tparam Args The types of the arguments to the function.
 */
template <typename ReturnType, typename... Args>
class ErrorHandler
{
	public:
	    /**
		* @brief Constructs an ErrorHandler with a given function.
		*
		* @param func The function to be handled by the ErrorHandler. It should be a std::function that takes arguments of types Args and returns a value of type ReturnType.
		*/
	    explicit ErrorHandler(std::function<ReturnType(Args...)> func);
	    /**
		 * @brief Invokes the stored function with the given arguments and handles any exceptions.
		 *
		 * @param args The arguments to be passed to the stored function.
		 * @return The result of the function if no exception is thrown, or a default-constructed ReturnType if an exception is caught.
		 */
	    ReturnType operator()(Args... args);

	private:
		/**
	   * @brief Handles a function, attempting to execute the stored function with the given arguments.
	   *
	   * Forwards the arguments to the stored function and returns its result.
	   * If an exception is thrown during the execution of the function, it is caught and handled.
	   *
	   * @param args The arguments to be passed to the stored function.
	   * @return The result of the function if no exception is thrown.
	   */
		std::function<ReturnType(Args...)> func_; ///< 
};
#endif //ERROR_HANDLER_H

/**Implementation of the template class **/
template <typename ReturnType, typename... Args>
ErrorHandler<ReturnType, Args...>::ErrorHandler(std::function<ReturnType(Args...)> func)
    : func_(std::move(func)) {}

template <typename ReturnType, typename... Args>
ReturnType ErrorHandler<ReturnType, Args...>::operator()(Args... args)
{
	try 
    {
        return func_(std::forward<Args>(args)...); // Attempts to execute the stored function with the given arguments.
    }
	catch (const std::exception& e) 
	{
        std::cerr
    	<< "Exception caught: "
    	<< e.what()
    	<< "\n";

        return ReturnType(); // Return default constructed ReturnType
    }
    catch (...) 
	{
        std::cerr
    	<< "Unknown exception caught: "
    	<< "\n";
        return ReturnType(); // Return default constructed ReturnType
    }
}