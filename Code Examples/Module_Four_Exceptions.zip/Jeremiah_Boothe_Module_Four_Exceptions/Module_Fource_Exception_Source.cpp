// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
#include <stdexcept>
#include <iostream>
#include "ErrorHandler.h"

/**
 * @class custom_exception
 * @brief A custom exception class derived from std::exception.
 */
class custom_exception final : public std::exception {
	public:
        /**
	     * @brief Returns a C-string describing the custom exception.
	     * @return A C-string "Custom exception occurred!".
	     */
	    [[nodiscard]] const char* what() const noexcept override {
	        return "My Custom Exception occurred!";
	    }
};

/**
 * @brief Performs more complex custom application logic and throws a standard exception.
 * @throws std::runtime_error if a certain condition is met.
 * @return Always returns false in this implementation.
 */
bool do_even_more_custom_application_logic() {

	// TODO: Throw any standard exception
    std::cout
		<< "Running Even More Custom Application Logic."
		<< " ..."
		<< "\n";

    // Always evaluates to true to throw error.
    if constexpr (true) {
        throw std::runtime_error("Standard Exception - Runtime Error: thrown in do_even_more_custom_application_logic");
    }
}

/**
 * @brief Executes custom application logic, uses an ErrorHandler to manage exceptions, and throws a custom exception.
 * @throws custom_exception after executing custom logic.
 */
void do_custom_application_logic() {

    std::cout
		<< "Running Custom Application Logic...\n";

    /**
	 * @brief Instantiates an ErrorHandler for handling exceptions in do_even_more_custom_application_logic.
	 *
	 * ErrorHandler uses a lambda to capture all external variables by reference.
	 *
	 * @param [&] Capturing external variables by reference allows the lambda to access
	 *            variables in the enclosing scope.
	 * @return A boolean value indicating the success of the do_even_more_custom_application_logic function.
	 */
    ErrorHandler<bool> errorHandler([&]() -> bool 
    {
        return do_even_more_custom_application_logic();
    });

    
    errorHandler(); // Use the ErrorHandler to catch exceptions

    std::cout
		<< "Leaving Custom Application Logic.\n";

    throw custom_exception(); // Throw a custom exception
}

/**
 * @brief Divides two floating-point numbers and handles division by zero using hashing.
 *
 * Simple Division.
 *
 * @tparam float The numerator.
 * @tparam float The denominator.

 * @return float The result of the division if the denominator is not zero.
 */
float divide(const float num, const float den)
{
			//TODO: Throw an exception to deal with divide by zero errors using
			// Error Handled in the do_division() function call
            return (num / den);
}

 /**
  * @brief This function is designed to hash the values of the denominator against zero, to deal with potential
  * issues resulting from float precision and/or truncation. A bitwise XOR operator is used to compare the hashing
  * of denominator against the hashing of zero.
  *
  * This function also uses a custom ErrorHandler to manage the division operation and prints the result if successful.
  * If a divide by zero error occurs, it catches and handles the exception.
  *
  * @exception Uses custom ErrorHandler<ReturnType, Args> Template, of my own design, that dynamically adapts to errors.
  */
void do_division() noexcept
{
	constexpr float numerator = 10.0f; // compile-time checked numerator
    constexpr float denominator = 0; // compile-time checked denominator
    /**
	* @brief Instantiates an ErrorHandler for handling division operations and catching divide-by-zero errors.
	*
	* This ErrorHandler is designed to call the divide function with the provided numerator and denominator.
	* It checks if the denominator is effectively zero by comparing hashed values and handles the divide-by-zero
	* scenario by returning 0 and printing an error message.
	*
	* @param numerator The numerator for the division operation.
	* @param denominator The denominator for the division operation.
	* @return The result of the division if the denominator is not zero; otherwise, returns 0.
	*/
	ErrorHandler<float,	float, float> errorHandler([](float numerator, float denominator) -> float 
        {
        const std::size_t zero_h = std::hash<float>{}(0);
        const std::size_t den_h = std::hash<float>{}(denominator);
        if (zero_h ^ den_h) // bitwise XOR determines the values are not equal, and returns the result of division
        {
            return divide(numerator, denominator);
        }

		std::cerr
			<< "Error: Attempt to Divide-by-Zero Detected.\n"
			<< "\n";
		return 0;
    });

    if (const float result = errorHandler(numerator, denominator); result != 0.0f) {
        std::cout
    		<< "divide("
    		<< numerator
    		<< ", "
    		<< denominator
    		<< ") = "
    		<< result
    		<< "\n";
    }
}

/**
 * @brief The main function that tests various exception handling scenarios.
 *
 * This function sets up an ErrorHandler to manage the execution of custom application logic
 * and division operations, catches different types of exceptions, and displays messages to the console.
 * It is probably a bit redundant to wrap everything in an ErrorHandler template, and call that function in a try/catch block.
 * The reasoning is that in best practices error handling would be comprehensive but having a final top level catch,
 * in case something slips by, would be a contingency or last line of defense or as a tool to find new errors, at which point
 * the ErrorHandler Template Implementation would be modified to explicitly handle the new error. 
 *
 * @return An integer indicating the exit status of the program.
 */
int main()
{
    std::cout
		<< "#####  Exceptions Tests!  ####"
		<< "\n\n";

    //  TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.

    // Errorhandler wraps all function calls in main, handling explicitly defined errors.
    ErrorHandler<void> mainHandler([&]()
    {
    	do_division();
        do_custom_application_logic();
    });

    try 
    {
    	// The ErrorHandler mainHandler function is called, creating a single point of entry to execute program functionality.
        mainHandler();
        // Uncaught exception, still need to figure out how to pass and display information about the uncaught error.
        throw std::domain_error("Intentionally Uncaught Exception");
    }
    catch (...)
    {
	    std::cerr
		    << "Caught an Unknown Exception in Main"
		    << "\n";
    }
    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu