#pragma once

bool run_query(sqlite3* db, const std::string& sql, std::vector<user_record>& records)
{
    // TODO: Fix this method to fail and display an error if there is a suspected SQL Injection
    //  NOTE: You cannot just flag 1=1 as an error, since 2=2 will work just as well. You need
    //  something more generic


    // Define the regex pattern to detect any ASCII characters around the equal sign
    std::regex injection_pattern(R"(([\x00-\x7F]+)\s*=\s*([\x00-\x7F]+))");
    char* error_message;
    if ((std::regex_search(sql, injection_pattern)) || (sqlite3_exec(db, sql.c_str(), callback, &records, &error_message) != SQLITE_OK))
    {
        std::cout << "Data failed to be queried from USERS table. ERROR = " << error_message << std::endl;
        sqlite3_free(error_message);
        return false;

        // clear any prior results
        records.clear();
    }

    return true;
}
